ArangoDB - a distributed database with a flexible data model for documents, graphs, and key-values.
