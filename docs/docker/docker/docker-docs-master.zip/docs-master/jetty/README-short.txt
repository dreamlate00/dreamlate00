Jetty provides a Web server and javax.servlet container.
