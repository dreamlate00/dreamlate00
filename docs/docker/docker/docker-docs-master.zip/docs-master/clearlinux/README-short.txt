Official docker build of Clear Linux OS for Intel Architecture
