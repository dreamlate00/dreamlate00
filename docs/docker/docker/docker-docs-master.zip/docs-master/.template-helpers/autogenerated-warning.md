<!--

********************************************************************************

WARNING:

    DO NOT EDIT "%%REPO%%/README.md"

    IT IS AUTO-GENERATED

    (from the other files in "%%REPO%%/" combined with a set of templates)

********************************************************************************

-->
