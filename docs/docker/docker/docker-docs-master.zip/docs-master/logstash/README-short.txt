Logstash is a tool for managing events and logs.
