View [license information](https://github.com/ExpressGateway/express-gateway/blob/master/LICENSE) for the software contained in this image.
