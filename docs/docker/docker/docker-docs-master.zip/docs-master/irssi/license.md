View [license information](https://github.com/irssi/irssi/blob/master/COPYING) for the software contained in this image.
