Lightstreamer is a real-time messaging server optimized for the Internet.
