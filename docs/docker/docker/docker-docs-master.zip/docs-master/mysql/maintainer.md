[the Docker Community and the MySQL Team](%%GITHUB-REPO%%)
