View [license information](http://eclipse.org/jetty/licenses.html) for the software contained in this image.
