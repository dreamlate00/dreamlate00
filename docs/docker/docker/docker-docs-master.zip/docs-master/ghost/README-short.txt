Ghost is a free and open source blogging platform written in JavaScript
