View [license information](https://github.com/influxdata/kapacitor/blob/master/LICENSE) for the software contained in this image.
