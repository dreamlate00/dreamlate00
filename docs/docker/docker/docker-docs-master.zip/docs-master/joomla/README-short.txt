Joomla! is an open source content management system.
