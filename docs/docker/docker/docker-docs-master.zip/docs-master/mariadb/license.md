View [license information](https://mariadb.com/kb/en/library/licensing-faq/) for the software contained in this image.
