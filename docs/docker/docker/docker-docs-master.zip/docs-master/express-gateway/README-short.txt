The Official Docker Image of Express Gateway, an API Gateway for APIs and Microservices
