Aerospike – the reliable, high performance, distributed database optimized for flash and RAM.
