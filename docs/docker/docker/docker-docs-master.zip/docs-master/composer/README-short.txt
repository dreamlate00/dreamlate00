Composer is a dependency manager written in and for PHP.
