The GNU Compiler Collection is a compiling system that supports several languages.
