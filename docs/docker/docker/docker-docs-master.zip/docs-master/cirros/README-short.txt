CirrOS is a Tiny OS that specializes in running on a cloud.
