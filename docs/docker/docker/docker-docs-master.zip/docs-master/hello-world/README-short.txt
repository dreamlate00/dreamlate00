Hello World! (an example of minimal Dockerization)
