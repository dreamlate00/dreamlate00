Convertigo Community Edition MBaaS image is licenced under [AGPL 3.0](http://www.gnu.org/licenses/agpl-3.0.html)
