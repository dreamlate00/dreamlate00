Bash is the GNU Project's Bourne Again SHell
