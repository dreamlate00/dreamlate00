MySQL is a widely used, open-source relational database management system (RDBMS).
