Bonita is an open-source business process management and workflow suite
