View [license information](https://www.mageia.org/en/about/license/) for the software contained in this image.
