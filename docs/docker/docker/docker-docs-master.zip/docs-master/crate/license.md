CrateDB is licensed under the Apache License 2.0.

See [LICENSE](https://github.com/crate/crate/blob/master/LICENSE) for more information.
