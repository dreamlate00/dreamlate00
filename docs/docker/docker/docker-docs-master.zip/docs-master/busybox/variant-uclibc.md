## `%%IMAGE%%:uclibc`

-	[uClibc](https://uclibc.org) via [Buildroot](https://buildroot.org) (statically compiled)
