View [license information](https://konghq.com/kong/license/) for the software contained in this image.
