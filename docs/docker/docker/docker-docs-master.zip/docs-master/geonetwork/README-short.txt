GeoNetwork is a FOSS catalog for spatially referenced resources.
