View [license information](http://clojure.org/license) for the software contained in this image.
