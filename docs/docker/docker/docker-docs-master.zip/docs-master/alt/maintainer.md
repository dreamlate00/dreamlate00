[The ALT Linux Team Cloud](%%GITHUB-REPO%%)
