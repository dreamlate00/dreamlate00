View [license information](https://github.com/jruby/jruby/blob/master/COPYING) for the software contained in this image.
