View [license information](https://github.com/varnish/hitch/blob/master/LICENSE) for the software contained in this image.
