Dart is a client-optimized language for fast apps on any platform.
