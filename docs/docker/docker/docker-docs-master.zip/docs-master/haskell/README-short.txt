Haskell is an advanced purely-functional programming language.
