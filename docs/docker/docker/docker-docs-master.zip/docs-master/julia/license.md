View [license information](http://julialang.org/) for the software contained in this image.
