View [license information](https://backdropcms.org/license) for the software contained in this image.
