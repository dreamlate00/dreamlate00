Web-based MongoDB admin interface, written with Node.js and express
