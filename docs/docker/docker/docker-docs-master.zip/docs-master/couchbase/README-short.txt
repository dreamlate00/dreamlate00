Couchbase Server is a NoSQL document database with a distributed architecture.
