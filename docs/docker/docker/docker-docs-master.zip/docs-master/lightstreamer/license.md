View [license information](https://www.lightstreamer.com/lightstreamer-sla) for the software contained in this image.
