View [license information](https://launchpad.net/cirros) for the software contained in this image:

> The code for building CirrOS is available under GPLv2. The binary images that will be distributed contain many different licenses all of which are opensource.
