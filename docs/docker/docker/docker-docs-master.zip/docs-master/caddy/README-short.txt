Caddy 2 is a powerful, enterprise-ready, open source web server with automatic HTTPS written in Go.
