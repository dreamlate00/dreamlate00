[ArangoDB](%%GITHUB-REPO%%)
