[Eggheads (the Eggdrop community)](%%GITHUB-REPO%%)
