Hy is a Lisp dialect that translates expressions into Python's abstract syntax tree.
