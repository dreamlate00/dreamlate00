View [license information](https://www.basealt.ru/products/starterkits/) for the software contained in this image.
