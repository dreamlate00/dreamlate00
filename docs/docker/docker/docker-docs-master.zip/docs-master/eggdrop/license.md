View [license information](https://www.gnu.org/licenses/gpl-3.0.en.html) for the software contained in this image.
