Busybox base image.
