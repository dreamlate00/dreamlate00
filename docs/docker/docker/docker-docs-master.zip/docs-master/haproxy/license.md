View [license information](http://www.haproxy.org/download/1.5/doc/LICENSE) for the software contained in this image.
