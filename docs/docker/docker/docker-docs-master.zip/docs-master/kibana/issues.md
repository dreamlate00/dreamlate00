For issues with the Kibana Docker image or Kibana: %%GITHUB-REPO%%/issues
