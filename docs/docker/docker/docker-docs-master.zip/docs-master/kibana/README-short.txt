Kibana gives shape to any kind of data — structured and unstructured — indexed in Elasticsearch.
