The official build of ALT Linux.
