[the AWS JDK team](%%GITHUB-REPO%%)
