Apache Flink® is a powerful open-source distributed stream and batch processing framework.
