[Tianon (of the Docker Community)](%%GITHUB-REPO%%), [with Chet's support (from Bash upstream)](https://github.com/docker-library/official-images/pull/2217#issue-181031192)
