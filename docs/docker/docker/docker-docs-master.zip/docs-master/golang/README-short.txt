Go (golang) is a general purpose, higher-level, imperative programming language.
