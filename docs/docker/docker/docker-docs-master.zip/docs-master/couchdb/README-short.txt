CouchDB is a database that uses JSON for documents, an HTTP API, & JavaScript/declarative indexing.
