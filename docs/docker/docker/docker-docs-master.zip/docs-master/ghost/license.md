View [license information](https://ghost.org/license/) for the software contained in this image.
