View [license information](https://github.com/mongo-express/mongo-express#license) for the software contained in this image.
