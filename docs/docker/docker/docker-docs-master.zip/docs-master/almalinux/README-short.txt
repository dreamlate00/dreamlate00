The official build of AlmaLinux OS.
