View [license information](https://github.com/vrana/adminer/blob/master/readme.txt) for the software contained in this image.
