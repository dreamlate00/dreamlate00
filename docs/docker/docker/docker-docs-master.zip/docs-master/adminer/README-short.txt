Database management in a single PHP file.
