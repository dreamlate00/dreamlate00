InfluxDB is an open source time series database for recording metrics, events, and analytics.
