View [license information](https://github.com/docker-library/hello-world/blob/master/LICENSE) for the software contained in this image.
