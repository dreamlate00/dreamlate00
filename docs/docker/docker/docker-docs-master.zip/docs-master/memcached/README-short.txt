Free & open source, high-performance, distributed memory object caching system.
