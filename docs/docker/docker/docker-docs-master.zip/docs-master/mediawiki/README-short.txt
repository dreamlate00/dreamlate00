MediaWiki is a free software open source wiki package written in PHP.
