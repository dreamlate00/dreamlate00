MongoDB document databases provide high availability and easy scalability.
