irssi - The IRC client of the future
