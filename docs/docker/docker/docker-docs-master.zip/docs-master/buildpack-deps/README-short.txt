A collection of common build dependencies used for installing various modules, e.g., gems.
