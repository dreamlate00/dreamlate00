View [license information](https://www.apache.org/licenses/) for the software contained in this image.
