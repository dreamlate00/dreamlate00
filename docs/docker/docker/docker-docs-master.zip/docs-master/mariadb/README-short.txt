MariaDB Server is a high performing open source relational database, forked from MySQL.
