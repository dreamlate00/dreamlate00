For issues with Logstash Docker Image or Logstash: %%GITHUB-REPO%%/issues
