Erlang is a programming language used to build massively scalable systems with high availability.
