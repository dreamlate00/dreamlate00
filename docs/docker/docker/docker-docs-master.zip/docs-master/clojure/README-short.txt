Clojure is a dialect of Lisp that runs on the JVM.
