Official Mageia base image
