Official IBM® SDK, Java™ Technology Edition Docker Image.
