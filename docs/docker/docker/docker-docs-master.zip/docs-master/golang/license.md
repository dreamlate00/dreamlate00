View [license information](http://golang.org/LICENSE) for the software contained in this image.
