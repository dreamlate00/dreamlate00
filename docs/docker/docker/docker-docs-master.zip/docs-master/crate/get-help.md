[project documentation](https://crate.io/docs/), [StackOverflow](https://stackoverflow.com/tags/cratedb), [support channels](https://crate.io/support/)
