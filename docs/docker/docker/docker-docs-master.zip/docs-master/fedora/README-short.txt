Official Docker builds of Fedora
