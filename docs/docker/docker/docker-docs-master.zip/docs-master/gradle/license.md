View [license information](https://gradle.org/license/) for the software contained in this image.
