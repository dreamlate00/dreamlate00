Debian is a Linux distribution that's composed entirely of free and open-source software.
