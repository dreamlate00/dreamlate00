View [license information](http://www.gnu.org/licenses/gpl-2.0.txt) for the software contained in this image.
