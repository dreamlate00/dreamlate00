Jobber is an alternative to cron, with sophisticated status-reporting and error-handling.
