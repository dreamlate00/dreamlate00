Gradle is a build tool with a focus on build automation and support for multi-language development.
