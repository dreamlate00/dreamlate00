[Mageia Developers](%%GITHUB-REPO%%)
