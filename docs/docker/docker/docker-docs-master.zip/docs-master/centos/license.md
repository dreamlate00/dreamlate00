View [license information](https://www.centos.org/legal/) for the software contained in this image.
