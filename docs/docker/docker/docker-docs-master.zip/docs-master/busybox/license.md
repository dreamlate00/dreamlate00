View [license information](http://www.busybox.net/license.html) for the software contained in this image.
