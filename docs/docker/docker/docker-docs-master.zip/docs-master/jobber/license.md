[Jobber's license](https://github.com/dshearer/jobber/blob/master/LICENSE)
