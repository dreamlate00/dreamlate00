Hitch is a libev-based high performance SSL/TLS proxy by Varnish Software.
