[Bonitasoft Community](%%GITHUB-REPO%%)
