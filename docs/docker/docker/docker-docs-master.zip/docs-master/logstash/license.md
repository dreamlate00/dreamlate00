View [license information](https://github.com/elastic/logstash/blob/6.4/licenses/ELASTIC-LICENSE.txt) for the software contained in this image.
