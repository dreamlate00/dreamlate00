Apache Groovy is a multi-faceted language for the Java platform.
