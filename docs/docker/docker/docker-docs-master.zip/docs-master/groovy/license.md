View [license information](http://www.apache.org/licenses/LICENSE-2.0.html) for the software contained in this image.
