[GeoNetwork opensource](%%GITHUB-REPO%%)
