Amazon Linux provides a stable, secure, and high-performance execution environment for applications.
