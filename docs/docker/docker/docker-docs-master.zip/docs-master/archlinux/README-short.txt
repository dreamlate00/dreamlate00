Arch Linux is a simple, lightweight Linux distribution aimed for flexibility.
