View [licensing information](https://fedoraproject.org/wiki/Licensing:Main) for the software contained in this image.
