A minimal Docker image based on Alpine Linux with a complete package index and only 5 MB in size!
