Corretto is a no-cost, production-ready distribution of the Open Java Development Kit (OpenJDK).
