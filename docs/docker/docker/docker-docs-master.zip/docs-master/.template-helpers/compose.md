... via [`docker-compose`](https://github.com/docker/compose)

Example `docker-compose.yml` for `%%REPO%%`:

%%COMPOSE-YML%%
