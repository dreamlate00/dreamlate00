Gazebo is open-source licensed under [Apache 2.0](http://opensource.org/licenses/Apache-2.0).
