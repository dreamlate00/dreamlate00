Kapacitor is an open source framework for processing, monitoring, and alerting on time series data.
