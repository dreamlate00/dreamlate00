View [license information](https://almalinux.org/legal/licensing-policy/) for the software contained in this image.
