[Keegan Witt (of the Groovy Project)](%%GITHUB-REPO%%), [with the Gradle Project's approval](https://discuss.gradle.org/t/official-docker-images/21159/8)
