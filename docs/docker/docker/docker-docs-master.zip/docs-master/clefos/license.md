View [license information](https://github.com/nealef/clefos/blob/master/LICENSE.md) for the scripts which created this image.
