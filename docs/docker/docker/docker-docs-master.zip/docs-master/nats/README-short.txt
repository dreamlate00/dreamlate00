NATS is an open-source, high-performance, cloud native messaging system.
