Chronograf is a visualization tool for time series data in InfluxDB.
