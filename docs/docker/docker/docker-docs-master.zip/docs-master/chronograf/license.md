View [license information](https://github.com/influxdata/chronograf/blob/master/LICENSE) for the software contained in this image.
