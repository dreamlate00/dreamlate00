Official Images for OpenJDK binaries built by Eclipse Temurin.
