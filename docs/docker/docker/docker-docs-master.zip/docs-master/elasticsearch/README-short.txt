Elasticsearch is a powerful open source search and analytics engine that makes data easy to explore.
