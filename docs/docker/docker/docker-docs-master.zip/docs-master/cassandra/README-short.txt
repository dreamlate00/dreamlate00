Apache Cassandra is an open-source distributed storage system.
