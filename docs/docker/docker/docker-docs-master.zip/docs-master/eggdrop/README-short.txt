The official Docker image of Eggdrop- IRC's oldest actively-developed bot!
