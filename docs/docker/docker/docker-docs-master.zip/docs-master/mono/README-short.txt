Mono is an open source implementation of Microsoft's .NET Framework
