[Jessie and Tianon (of the Docker Community)](%%GITHUB-REPO%%), [with the appreciation of the Irssi Project](https://twitter.com/GeertHauwaerts/status/559131523145035776)
