View [license information](https://www.mysql.com/about/legal/) for the software contained in this image.
