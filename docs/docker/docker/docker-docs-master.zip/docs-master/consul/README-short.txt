Consul is a datacenter runtime that provides service discovery, configuration, and orchestration.
