For issues with Elasticsearch Docker Image or Elasticsearch: %%GITHUB-REPO%%/issues
