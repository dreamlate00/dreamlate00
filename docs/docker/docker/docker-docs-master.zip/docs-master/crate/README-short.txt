CrateDB is a distributed SQL database that handles massive amounts of machine data in real-time.
