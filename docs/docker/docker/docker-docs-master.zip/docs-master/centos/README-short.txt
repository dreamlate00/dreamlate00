The official build of CentOS.
