View [license information](https://github.com/friendica/server/blob/master/LICENSE) for the software contained in this image.
