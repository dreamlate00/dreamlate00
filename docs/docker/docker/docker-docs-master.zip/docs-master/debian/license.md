View [license information](https://www.debian.org/social_contract#guidelines) for the software contained in this image.
